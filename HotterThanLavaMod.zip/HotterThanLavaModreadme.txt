Hotter Than Lava Mod
https://github.com/rainbowdesign/HotterThanLavaMod/
The mod consists of different files:

LavaHeaterMod.dll
make certain buildings immune to overheating and makes sure you can boil elements to liquid.

AnimalsMod.dll
Animals can now produce much more elements inclusive water and Pyrite.

ElementsMod.dll
A new Elements Chain that makes it much harder to build endgame Buildings.

External mods are included in the folder they are from:
https://github.com/javisar/ONI-Modloader-Mods
