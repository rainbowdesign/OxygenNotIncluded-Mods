﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using Harmony;
using TUNING;
using UnityEngine;

namespace SuperWireBridge
{
	internal class IDS
	{
		public const string ID = "SuperWireBridge";
		public const string NAME = "Super Wire Bridge";
		public const string DESCRIPTION = "The Super Wire Bridge can transport 50000 Watts.";
		public const string EFFECT = "A very strong but expensive wire bridge to connect in lategame.";
		public const string TECH = "PrettyGoodConductors";
		public const string PLANCATEGORY = "Power";
	}
	[HarmonyPatch(typeof(GeneratedBuildings), "LoadGeneratedBuildings")]
	internal class __LoadGeneratedBuildings
	{
		private static void Prefix()
		{
            Co.Add.BuildingPlan(IDS.ID, IDS.NAME, IDS.DESCRIPTION, IDS.EFFECT, IDS.PLANCATEGORY);
		}
	}
	[HarmonyPatch(typeof(Db), "Initialize")]
	internal class __Db_Initialize
	{
		private static void Prefix(Db __instance)
		{
            Co.Add.BuildingTech(IDS.ID, IDS.TECH);
        }
	}
	public class SuperWireRefinedBridgeConfig : WireBridgeConfig
	{
		public new const string ID = IDS.ID;

		protected override string GetID()
		{
			return IDS.ID;
		}

		public override BuildingDef CreateBuildingDef()
		{
			BuildingDef buildingDef = base.CreateBuildingDef();
			buildingDef.AnimFiles = new KAnimFile[1]
			{
	  Assets.GetAnim((HashedString) "utilityelectricbridgeconductive_kanim")
			};
			float[] construction_mass = new float[3] { 60, 20, 20 };
			string[] construction_materials = new string[3]
			{
				SimHashes.Steel.ToString(),
				SimHashes.TempConductorSolid.ToString(),
				"Plastic"
			};
			buildingDef.Mass = construction_mass;
			buildingDef.MaterialCategory = construction_materials;
			GeneratedBuildings.RegisterWithOverlay(OverlayScreen.WireIDs, "WireRefinedBridge");
			return buildingDef;
		}

		protected override WireUtilityNetworkLink AddNetworkLink(GameObject go)
		{
			WireUtilityNetworkLink utilityNetworkLink = base.AddNetworkLink(go);
			utilityNetworkLink.maxWattageRating = Wire.WattageRating.Max50000;
			return utilityNetworkLink;
		}
	}
}
