﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using Harmony;
using TUNING;
using UnityEngine;

namespace IsolatedWire
{
	internal class IDS
	{
		public const string ID = "IsolatedWire";
		public const string NAME = "Isolated Wire";
		public const string DESCRIPTION = "The Isolated Wire can transport 5000 Watts.";
		public const string EFFECT = "A good but expensive wire to connect in midgame.";
		public const string TECH = "PrettyGoodConductors";
		public const string PLANCATEGORY = "Power";
	}
	[HarmonyPatch(typeof(GeneratedBuildings), "LoadGeneratedBuildings")]
	internal class __LoadGeneratedBuildings
	{
		private static void Prefix()
		{
            Co.Add.BuildingPlan(IDS.ID, IDS.NAME, IDS.DESCRIPTION, IDS.EFFECT, IDS.PLANCATEGORY);
		}
	}
	[HarmonyPatch(typeof(Db), "Initialize")]
	internal class __Db_Initialize
	{
		private static void Prefix(Db __instance)
		{
            Co.Add.BuildingTech(IDS.ID, IDS.TECH);
        }
	}
	public class SuperWireRefinedConfig : BaseWireConfig
	{
		public const string ID = IDS.ID;

		public override BuildingDef CreateBuildingDef()
		{
			string id = IDS.ID;
			string anim = "utilities_electric_conduct_kanim";
			float construction_time = 3f;
			float[] construction_mass = new float[2] { 30,10 };
			string[] construction_materials = new string[2]
			{
				"Gold",
				"Plastic"
			};
			float insulation = 0.05f;
			EffectorValues none = NOISE_POLLUTION.NONE;
			BuildingDef buildingDef = this.CreateBuildingDef(id, anim, construction_time, construction_mass, insulation, BUILDINGS.DECOR.NONE, none);
			buildingDef.MaterialCategory = construction_materials;
			return buildingDef;
		}

		public override void DoPostConfigureComplete(GameObject go)
		{
			this.DoPostConfigureComplete(Wire.WattageRating.Max5000, go);
		}
	}
}
