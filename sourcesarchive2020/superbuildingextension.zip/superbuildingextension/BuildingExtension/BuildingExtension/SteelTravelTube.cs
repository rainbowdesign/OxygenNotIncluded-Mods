﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using Harmony;
using TUNING;
using UnityEngine;

namespace SteelTravelTube
{
    internal class IDS
    {
        public const string ID = "SteelTravelTube";
        public const string NAME = "Steel Travel Tube";
        public const string DESCRIPTION = "The Steel Travel Tube is on the Background Layer and Heat resistant.";
        public const string EFFECT = "Use the Steel Travel Tube in hot areas and when you need to cross something.";
        public const string TECH = "TravelTubes";
        public const string PLANCATEGORY = "Base";
    }
    [HarmonyPatch(typeof(GeneratedBuildings), "LoadGeneratedBuildings")]
    internal class __LoadGeneratedBuildings
    {
        private static void Prefix()
        {
            Strings.Add("STRINGS.BUILDINGS.PREFABS." + IDS.ID.ToUpper() + ".NAME", IDS.NAME);
            Strings.Add("STRINGS.BUILDINGS.PREFABS." + IDS.ID.ToUpper() + ".DESC", IDS.DESCRIPTION);
            Strings.Add("STRINGS.BUILDINGS.PREFABS." + IDS.ID.ToUpper() + ".EFFECT", IDS.EFFECT);

            List<string> category = (List<string>)TUNING.BUILDINGS.PLANORDER.First(po => ((HashedString)IDS.PLANCATEGORY).Equals(po.category)).data;
            category.Add(IDS.ID);

            //TUNING.BUILDINGS.COMPONENT_DESCRIPTION_ORDER.Add(typeof(PressureLiquidReservoirConfig));
        }
    }
    [HarmonyPatch(typeof(Db), "Initialize")]
    internal class __Db_Initialize
    {
        private static void Prefix(Db __instance)
        {
            List<string> ls = new List<string>((string[])Database.Techs.TECH_GROUPING[IDS.TECH]);
            ls.Add(IDS.ID);
            Database.Techs.TECH_GROUPING[IDS.TECH] = (string[])ls.ToArray();
        }
    }
    public class SteelTravelTubeConfig : IBuildingConfig
    {
        public override BuildingDef CreateBuildingDef()
        {
            string id = "SteelTravelTube";
            int width = 1;
            int height = 1;
            string anim = "travel_tube_kanim";
            int hitpoints = 30;
            float construction_time = 10f;
            float[] tieR1 = BUILDINGS.CONSTRUCTION_MASS_KG.TIER1;
            string[] constmaterial = new string[1]
    {
      SimHashes.Steel.ToString()
    };
            float melting_point = 1600f;
            BuildLocationRule build_location_rule = BuildLocationRule.NotInTiles;
            EffectorValues none = NOISE_POLLUTION.NONE;
            BuildingDef buildingDef = BuildingTemplates.CreateBuildingDef(id, width, height, anim, hitpoints, construction_time, tieR1, constmaterial, melting_point, build_location_rule, BUILDINGS.DECOR.BONUS.TIER0, none, 0.2f);
            buildingDef.Floodable = false;
            buildingDef.Overheatable = false;
            buildingDef.Entombable = false;
            buildingDef.ObjectLayer = ObjectLayer.Backwall;
            buildingDef.TileLayer = ObjectLayer.TravelTubeTile;
            buildingDef.SceneLayer = Grid.SceneLayer.Backwall;
            buildingDef.BuildLocationRule= BuildLocationRule.Anywhere;
            buildingDef.ReplacementLayer = ObjectLayer.ReplacementTravelTube;
            buildingDef.AudioCategory = "Metal";
            buildingDef.AudioSize = "small";
            buildingDef.BaseTimeUntilRepair = 0.0f;
            buildingDef.UtilityInputOffset = new CellOffset(0, 0);
            buildingDef.UtilityOutputOffset = new CellOffset(0, 0);
            buildingDef.isKAnimTile = true;
            buildingDef.isUtility = true;
            buildingDef.DragBuild = true;
            buildingDef.ContinuouslyCheckFoundation=false;
            return buildingDef;
        }

        public override void ConfigureBuildingTemplate(GameObject go, Tag prefab_tag)
        {
            GeneratedBuildings.MakeBuildingAlwaysOperational(go);
            BuildingConfigManager.Instance.IgnoreDefaultKComponent(typeof(RequiresFoundation), prefab_tag);
            go.AddOrGet<TravelTube>();
        }

        public override void DoPostConfigureUnderConstruction(GameObject go)
        {
            KAnimGraphTileVisualizer graphTileVisualizer = go.AddComponent<KAnimGraphTileVisualizer>();
            graphTileVisualizer.connectionSource = KAnimGraphTileVisualizer.ConnectionSource.Tube;
            graphTileVisualizer.isPhysicalBuilding = false;
        }

        public override void DoPostConfigureComplete(GameObject go)
        {
            go.GetComponent<Building>().Def.BuildingUnderConstruction.GetComponent<Constructable>().isDiggingRequired = false;
            KAnimGraphTileVisualizer graphTileVisualizer = go.AddComponent<KAnimGraphTileVisualizer>();
            graphTileVisualizer.connectionSource = KAnimGraphTileVisualizer.ConnectionSource.Tube;
            graphTileVisualizer.isPhysicalBuilding = true;
        }

    }
}