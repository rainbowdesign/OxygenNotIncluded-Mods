﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using Harmony;
using TUNING;
using UnityEngine;
using Klei;
using STRINGS;


namespace SuperBuildingMod
{
    class Other
    {
        /*
        [HarmonyPatch(typeof(WireRefinedHighWattageConfig), "DoPostConfigureComplete", null)]
        public static class __WireRefinedHighWattageConfig
        {
            public static bool Prefix(ref GameObject go)
            {
                Wire.WattageRating rating = Wire.WattageRating.Max50000;
                go.GetComponent<Wire>().MaxWattageRating = rating;
                float maxWattageAsFloat = Wire.GetMaxWattageAsFloat(rating);
                Descriptor descriptor = new Descriptor();
                descriptor.SetupDescriptor(string.Format((string)UI.BUILDINGEFFECTS.MAX_WATTAGE, (object)GameUtil.GetFormattedWattage(maxWattageAsFloat, GameUtil.WattageFormatterUnit.Automatic)), string.Format((string)UI.BUILDINGEFFECTS.TOOLTIPS.MAX_WATTAGE), Descriptor.DescriptorType.Effect);
                BuildingDef def = go.GetComponent<Building>().Def;
                if (def.EffectDescription == null)
                    def.EffectDescription = new List<Descriptor>();
                def.EffectDescription.Add(descriptor);
                return false;
            }
        }
        [HarmonyPatch(typeof(WireRefinedBridgeHighWattageConfig), "DoPostConfigureComplete", null)]
        public static class __WireRefinedBridgeHighWattageConfig
        {
            public static bool Prefix(ref GameObject go)
            {
                Wire.WattageRating rating = Wire.WattageRating.Max50000;
                go.GetComponent<Wire>().MaxWattageRating = rating;
                float maxWattageAsFloat = Wire.GetMaxWattageAsFloat(rating);
                Descriptor descriptor = new Descriptor();
                descriptor.SetupDescriptor(string.Format((string)UI.BUILDINGEFFECTS.MAX_WATTAGE, (object)GameUtil.GetFormattedWattage(maxWattageAsFloat, GameUtil.WattageFormatterUnit.Automatic)), string.Format((string)UI.BUILDINGEFFECTS.TOOLTIPS.MAX_WATTAGE), Descriptor.DescriptorType.Effect);
                BuildingDef def = go.GetComponent<Building>().Def;
                if (def.EffectDescription == null)
                    def.EffectDescription = new List<Descriptor>();
                def.EffectDescription.Add(descriptor);
                return false;
            }
        }

    */
    }
}
