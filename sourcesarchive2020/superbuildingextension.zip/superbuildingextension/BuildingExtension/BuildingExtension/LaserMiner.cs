﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using Harmony;
using TUNING;
using UnityEngine;

namespace LaserMiner
{
    internal class IDS
    {
        public const string ID = "LaserMiner";
        public const string NAME = "Laser Miner";
        public const string DESCRIPTION = "The Laser Miner Drills a Long Holes.";
        public const string EFFECT = "The Laser Miner is perfect to drill tunnels or clean comet residue.";
        public const string TECH = "SolidTransport";
        public const string PLANCATEGORY = "Conveyance";
    }
    [HarmonyPatch(typeof(GeneratedBuildings), "LoadGeneratedBuildings")]
    internal class __LoadGeneratedBuildings
    {
        private static void Prefix()
        {
            Co.Add.BuildingPlan(IDS.ID, IDS.NAME, IDS.DESCRIPTION, IDS.EFFECT, IDS.PLANCATEGORY);
        }
    }
    [HarmonyPatch(typeof(Db), "Initialize")]
    internal class __Db_Initialize
    {
        private static void Prefix(Db __instance)
        {
            Co.Add.BuildingTech(IDS.ID, IDS.TECH);
        }
    }

	public class LaserMinerConfig : IBuildingConfig
	{
		public const string ID = IDS.ID;
        private const int RANGE = 40;
		private const int X = 0;
		private const int Y = 0;
		private const int WIDTH = 40;
		private const int HEIGHT = 4;
		private const int VISION_OFFSET = 1;
		private static readonly LogicPorts.Port[] INPUT_PORTS;

		public override BuildingDef CreateBuildingDef()
		{
			BuildingDef buildingDef = BuildingTemplates.CreateBuildingDef(IDS.ID, 2, 2, "auto_miner_kanim", 10, 10f, TUNING.BUILDINGS.CONSTRUCTION_MASS_KG.TIER3, MATERIALS.REFINED_METALS, 1600f, BuildLocationRule.OnFoundationRotatable, TUNING.BUILDINGS.DECOR.PENALTY.TIER2, TUNING.NOISE_POLLUTION.NOISY.TIER0, 0.2f);
			buildingDef.Floodable = false;
			buildingDef.AudioCategory = "Metal";
			buildingDef.RequiresPowerInput = true;
			buildingDef.EnergyConsumptionWhenActive = 120f;
			buildingDef.ExhaustKilowattsWhenActive = 0.0f;
			buildingDef.SelfHeatKilowattsWhenActive = 2f;
			buildingDef.PermittedRotations = PermittedRotations.R360;
			GeneratedBuildings.RegisterWithOverlay(OverlayScreen.SolidConveyorIDs, IDS.ID);
			return buildingDef;
		}

		public override void ConfigureBuildingTemplate(GameObject go, Tag prefab_tag)
		{
			go.AddOrGet<Operational>();
			go.AddOrGet<LoopingSounds>();
			go.AddOrGet<MiningSounds>();
		}

		public override void DoPostConfigurePreview(BuildingDef def, GameObject go)
		{
			GeneratedBuildings.RegisterLogicPorts(go, LaserMinerConfig.INPUT_PORTS);
			LaserMinerConfig.AddVisualizer(go, true);
		}

		public override void DoPostConfigureUnderConstruction(GameObject go)
		{
			GeneratedBuildings.RegisterLogicPorts(go, LaserMinerConfig.INPUT_PORTS);
			LaserMinerConfig.AddVisualizer(go, false);
		}

		public override void DoPostConfigureComplete(GameObject go)
		{
			GeneratedBuildings.RegisterLogicPorts(go, LaserMinerConfig.INPUT_PORTS);
			go.AddOrGet<LogicOperationalController>();
			AutoMiner autoMiner = go.AddOrGet<AutoMiner>();
			autoMiner.x = X;
			autoMiner.y = Y;
			autoMiner.width = WIDTH;
			autoMiner.height = HEIGHT;
			autoMiner.vision_offset = new CellOffset(0, 1);
			LaserMinerConfig.AddVisualizer(go, false);
		}

		private static void AddVisualizer(GameObject prefab, bool movable)
		{
			StationaryChoreRangeVisualizer choreRangeVisualizer = prefab.AddOrGet<StationaryChoreRangeVisualizer>();
			choreRangeVisualizer.x = X;
			choreRangeVisualizer.y = Y;
			choreRangeVisualizer.width = WIDTH;
			choreRangeVisualizer.height = HEIGHT;
			choreRangeVisualizer.vision_offset = new CellOffset(0, 1);
			choreRangeVisualizer.movable = movable;
			choreRangeVisualizer.blocking_tile_visible = false;
			KPrefabID component = prefab.GetComponent<KPrefabID>();
		}

		static LaserMinerConfig()
		{
			LaserMinerConfig.INPUT_PORTS = new LogicPorts.Port[1]
			{
	  LogicPorts.Port.InputPort(LogicOperationalController.PORT_ID, new CellOffset(0, 0), "Logic Port", "Logic Port", "Logic Port", false)
			};
		}

	}
}
