﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using Harmony;
using TUNING;
using UnityEngine;

namespace superminer
{/*
    public static class Extensions
    {
        public static bool ValidDigCell    (this AutoMiner original,int cell) 
        {
            Debug.Log(" width " + width + " " + height);

            if (original.width == 60 && original.height == 8) return Grid.Solid[cell] && !Grid.Foundation[cell];
            else return Grid.Solid[cell] && !Grid.Foundation[cell] && Grid.Element[cell].hardness < (byte)150;

        }
    }*/


    [HarmonyPatch(typeof(AutoMiner), "UpdateDig")]
    public class __UpdateDig
    {
        public static bool Prefix(AutoMiner __instance,float dt)
        {
            if (__instance.width == 64 && __instance.height == 8)
            {
                Rotatable rotatable = Traverse.Create(__instance).Field("rotatable").GetValue<Rotatable>();
                int dig_cell = Traverse.Create(__instance).Field("dig_cell").GetValue<int>();
                bool rotation_complete = Traverse.Create(__instance).Field("rotation_complete").GetValue<bool>();
                KBatchedAnimController arm_anim_ctrl = Traverse.Create(__instance).Field("arm_anim_ctrl").GetValue<KBatchedAnimController>();
                MiningSounds mining_sounds = Traverse.Create(__instance).Field("mining_sounds").GetValue<MiningSounds>();
                GameObject arm_go = Traverse.Create(__instance).Field("arm_go").GetValue<GameObject>();

                if (!(dig_cell != Grid.InvalidCell) || !rotation_complete) return false;
                Diggable.DoDigTick(dig_cell, dt);
                mining_sounds.SetPercentComplete(Grid.Damage[dig_cell]);
                Vector3 posCcc = Grid.CellToPosCCC(dig_cell, Grid.SceneLayer.FXFront2);
                posCcc.z = 0.0f;
                Vector3 position = arm_go.transform.GetPosition();
                position.z = 0.0f;
                float sqrMagnitude = (posCcc - position).sqrMagnitude;
                arm_anim_ctrl.GetBatchInstanceData().SetClipRadius(position.x, position.y, sqrMagnitude, true);
                if (__ValidDigCell.ValidDigCell(__instance, dig_cell)) return false;
                Traverse.Create(__instance).Field("dig_cell").SetValue(Grid.InvalidCell);
                Traverse.Create(__instance).Field("rotation_complete").SetValue(false);
            }
            return true;
        }
    }
    [HarmonyPatch(typeof(AutoMiner), "RefreshDiggableCell")]
    public class __RefreshDiggableCell
    {
        public static bool Prefix(AutoMiner __instance)
        {
            if (__instance.width == 64 && __instance.height == 8)
            {
                Rotatable rotatable = Traverse.Create(__instance).Field("rotatable").GetValue<Rotatable>();
                int dig_cell = Traverse.Create(__instance).Field("dig_cell").GetValue<int>();
                bool rotation_complete = Traverse.Create(__instance).Field("rotation_complete").GetValue<bool>();

                CellOffset offset1 = __instance.vision_offset;
                if ((bool)((UnityEngine.Object)rotatable))
                    offset1 = rotatable.GetRotatedCellOffset(__instance.vision_offset);
                int cell1 = Grid.PosToCell(__instance.transform.gameObject);
                int cell2 = Grid.OffsetCell(cell1, offset1);
                int x1;
                int y1;
                Grid.CellToXY(cell2, out x1, out y1);
                float num1 = float.MaxValue;
                int num2 = Grid.InvalidCell;
                Vector3 pos1 = Grid.CellToPos(cell2);
                bool flag = false;
                for (int index1 = 0; index1 < __instance.height; ++index1)
                {
                    for (int index2 = 0; index2 < __instance.width; ++index2)
                    {
                        CellOffset offset2 = new CellOffset(__instance.x + index2, __instance.y + index1);
                        if ((bool)((UnityEngine.Object)rotatable))
                            offset2 = rotatable.GetRotatedCellOffset(offset2);
                        int cell3 = Grid.OffsetCell(cell1, offset2);
                        if (Grid.IsValidCell(cell3))
                        {
                            int x2;
                            int y2;
                            Grid.CellToXY(cell3, out x2, out y2);
                            if (Grid.Solid[cell3] && !Grid.Foundation[cell3])
                            {
                                int x3 = x1;
                                int y3 = y1;
                                int x2_1 = x2;
                                int y2_1 = y2;
                                if (true)
                                {
                                    if (cell3 == dig_cell)
                                        flag = true;
                                    Vector3 pos2 = Grid.CellToPos(cell3);
                                    float num3 = Vector3.Distance(pos1, pos2);
                                    if ((double)num3 < (double)num1)
                                    {
                                        num1 = num3;
                                        num2 = cell3;
                                    }
                                }
                            }
                        }
                    }
                }
                if (flag || dig_cell == num2)
                    return false;

               Traverse.Create(__instance).Field("dig_cell").SetValue(num2);
               Traverse.Create(__instance).Field("rotation_complete").SetValue(rotation_complete);
                return false;
            }
            return true;
        }
    }

    public class __ValidDigCell
    {
        public static bool ValidDigCell(AutoMiner __instance, int cell)
        {
            int width = __instance.width;// Traverse.Create(__instance).Field("width").GetValue<int>();
            int height = __instance.height;// Traverse.Create(__instance).Field("height").GetValue<int>();
             return Grid.Solid[cell] && !Grid.Foundation[cell];
        }
    }
        internal class IDS
    {
        public const string ID = "SuperMiner";
        public const string NAME = "Super Miner";
        public const string DESCRIPTION = "The Super Miner Drills a Long, broad Hole through hard elements.";
        public const string EFFECT = "The Super Miner is perfect to drill tunnels through abyssalite.";
        public const string TECH = "SolidTransport";
        public const string PLANCATEGORY = "Conveyance";
    }
    [HarmonyPatch(typeof(GeneratedBuildings), "LoadGeneratedBuildings")]
    internal class __LoadGeneratedBuildings
    {
        private static void Prefix()
        {
            Co.Add.BuildingPlan(IDS.ID, IDS.NAME, IDS.DESCRIPTION, IDS.EFFECT, IDS.PLANCATEGORY);
        }
    }
    [HarmonyPatch(typeof(Db), "Initialize")]
    internal class __Db_Initialize
    {
        private static void Prefix(Db __instance)
        {
            Co.Add.BuildingTech(IDS.ID, IDS.TECH);
        }
    }

	public class SuperMinerConfig : IBuildingConfig
	{
		public const string ID = IDS.ID;
        private const int RANGE = 60;
		private const int X = -4;
		private const int Y = 0;
		private const int WIDTH = 64;
		private const int HEIGHT = 8;
		private const int VISION_OFFSET = 1;
		private static readonly LogicPorts.Port[] INPUT_PORTS;

		public override BuildingDef CreateBuildingDef()
		{
			BuildingDef buildingDef = BuildingTemplates.CreateBuildingDef(IDS.ID, 2, 2, "auto_miner_kanim", 10, 10f, TUNING.BUILDINGS.CONSTRUCTION_MASS_KG.TIER6, new string[1]
    {
      SimHashes.Steel.ToString()
    } , 1600f, BuildLocationRule.OnFoundationRotatable, TUNING.BUILDINGS.DECOR.PENALTY.TIER2, TUNING.NOISE_POLLUTION.NOISY.TIER0, 0.2f);
			buildingDef.Floodable = false;
			buildingDef.AudioCategory = "Metal";
			buildingDef.RequiresPowerInput = true;
			buildingDef.EnergyConsumptionWhenActive = 120f;
			buildingDef.ExhaustKilowattsWhenActive = 0.0f;
			buildingDef.SelfHeatKilowattsWhenActive = 2f;
			buildingDef.PermittedRotations = PermittedRotations.R360;
			GeneratedBuildings.RegisterWithOverlay(OverlayScreen.SolidConveyorIDs, IDS.ID);
			return buildingDef;
		}

		public override void ConfigureBuildingTemplate(GameObject go, Tag prefab_tag)
		{
			go.AddOrGet<Operational>();
			go.AddOrGet<LoopingSounds>();
			go.AddOrGet<MiningSounds>();
		}

		public override void DoPostConfigurePreview(BuildingDef def, GameObject go)
		{
			GeneratedBuildings.RegisterLogicPorts(go, SuperMinerConfig.INPUT_PORTS);
			SuperMinerConfig.AddVisualizer(go, true);
		}

		public override void DoPostConfigureUnderConstruction(GameObject go)
		{
			GeneratedBuildings.RegisterLogicPorts(go, SuperMinerConfig.INPUT_PORTS);
			SuperMinerConfig.AddVisualizer(go, false);
		}
		public override void DoPostConfigureComplete(GameObject go)
		{
			GeneratedBuildings.RegisterLogicPorts(go, SuperMinerConfig.INPUT_PORTS);
			go.AddOrGet<LogicOperationalController>();
			AutoMiner autoMiner = go.AddOrGet<AutoMiner>();
			autoMiner.x = X;
			autoMiner.y = Y;
			autoMiner.width = WIDTH;
			autoMiner.height = HEIGHT;
			autoMiner.vision_offset = new CellOffset(0, 1);
			SuperMinerConfig.AddVisualizer(go, false);
		}

		private static void AddVisualizer(GameObject prefab, bool movable)
		{
			StationaryChoreRangeVisualizer choreRangeVisualizer = prefab.AddOrGet<StationaryChoreRangeVisualizer>();
			choreRangeVisualizer.x = X;
			choreRangeVisualizer.y = Y;
			choreRangeVisualizer.width = WIDTH;
			choreRangeVisualizer.height = HEIGHT;
			choreRangeVisualizer.vision_offset = new CellOffset(0, 1);
			choreRangeVisualizer.movable = movable;
			choreRangeVisualizer.blocking_tile_visible = false;
			KPrefabID component = prefab.GetComponent<KPrefabID>();
		}

		static SuperMinerConfig()
		{
			SuperMinerConfig.INPUT_PORTS = new LogicPorts.Port[1]
			{
	  LogicPorts.Port.InputPort(LogicOperationalController.PORT_ID, new CellOffset(0, 0), "Logic Port", "Logic Port", "Logic Port", false)
			};
		}

	}
}
