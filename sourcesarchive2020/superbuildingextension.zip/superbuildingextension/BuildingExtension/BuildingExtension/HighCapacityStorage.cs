﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using Harmony;
using TUNING;
using UnityEngine;

namespace HighCapacityStorage
{
    internal class IDS
    {
        public const string ID = "HighCapacityStorage";
        public const string NAME = "High Capacity Storage";
        public const string DESCRIPTION = "The High Capacity Storage can hold much more items.";
        public const string EFFECT = "Use The High Capacity Storage when you need to store aload.";
        public const string TECH = "SolidTransport";
        public const string PLANCATEGORY = "Base";
    }
    [HarmonyPatch(typeof(GeneratedBuildings), "LoadGeneratedBuildings")]
    internal class __LoadGeneratedBuildings
    {
        private static void Prefix()
        {
            Co.Add.BuildingPlan(IDS.ID, IDS.NAME, IDS.DESCRIPTION, IDS.EFFECT, IDS.PLANCATEGORY);
        }
    }
    [HarmonyPatch(typeof(Db), "Initialize")]
    internal class __Db_Initialize
    {
        private static void Prefix(Db __instance)
        {
            Co.Add.BuildingTech(IDS.ID, IDS.TECH);
        }
    }

    public class LaserMinerConfig : IBuildingConfig
    {
        public const string ID = IDS.ID;

        public override BuildingDef CreateBuildingDef()
        {
            string id = IDS.ID;
            int width = 1;
            int height = 2;
            string anim = "storagelocker_kanim";
            int hitpoints = 30;
            float construction_time = 10f;
            float[] tieR4 = BUILDINGS.CONSTRUCTION_MASS_KG.TIER6;
            string[] rawMinerals= new string[1]
    {
      SimHashes.Steel.ToString()
    };
            float melting_point = 1600f;
            BuildLocationRule build_location_rule = BuildLocationRule.Anywhere;
            EffectorValues none = NOISE_POLLUTION.NONE;
            BuildingDef buildingDef = BuildingTemplates.CreateBuildingDef(id, width, height, anim, hitpoints, construction_time, tieR4, rawMinerals, melting_point, build_location_rule, BUILDINGS.DECOR.PENALTY.TIER1, none, 0.2f);
            buildingDef.Floodable = false;
            buildingDef.AudioCategory = "Metal";
            buildingDef.Overheatable = false;
            return buildingDef;
        }

        public override void ConfigureBuildingTemplate(GameObject go, Tag prefab_tag)
        {
            SoundEventVolumeCache.instance.AddVolume("storagelocker_kanim", "StorageLocker_Hit_metallic_low", NOISE_POLLUTION.NOISY.TIER1);
            Prioritizable.AddRef(go);
            Storage storage = go.AddOrGet<Storage>();
            storage.showInUI = true;
            storage.allowItemRemoval = true;
            storage.showDescriptor = true;
            storage.storageFilters = STORAGEFILTERS.NOT_EDIBLE_SOLIDS;
            storage.storageFullMargin = STORAGE.STORAGE_LOCKER_FILLED_MARGIN;
            storage.fetchCategory = Storage.FetchCategory.GeneralStorage;
            storage.capacityKg= 2000000;
            go.AddOrGet<CopyBuildingSettings>().copyGroupTag = GameTags.StorageLocker;
            go.AddOrGet<StorageLocker>();
        }

        public override void DoPostConfigureComplete(GameObject go)
        {
            go.AddOrGetDef<StorageController.Def>();
        }

    }
}