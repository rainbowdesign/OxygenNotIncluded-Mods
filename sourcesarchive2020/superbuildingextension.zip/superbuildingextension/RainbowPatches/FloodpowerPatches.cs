﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Harmony;
using UnityEngine;
using STRINGS;

namespace RainbowBuildingPatches
{
    [HarmonyPatch(typeof(MassiveHeatSinkConfig), "CreateBuildingDef", null)]
    public static class MassiveHeatSinkConfigMod
    {
        public static void Postfix(BuildingDef __result)
        {

            __result.Floodable = false;
        }
    }
    [HarmonyPatch(typeof(SuitLockerConfig), "CreateBuildingDef", null)]
    public static class SuitLockerConfigMod
    {
        public static void Postfix(BuildingDef __result)
        {

            __result.Floodable = false;
        }
    }
    [HarmonyPatch(typeof(SuitMarkerConfig), "CreateBuildingDef", null)]
    public static class SuitMarkerConfigMod
    {
        public static void Postfix(BuildingDef __result)
        {
            __result.Floodable = false;
        }
    }
    [HarmonyPatch(typeof(TravelTubeEntranceConfig), "CreateBuildingDef", null)]
    public static class TravelTubeEntranceConfigMod
    {
        public static void Postfix(BuildingDef __result)
        {
            __result.Floodable = false;
        }
    }


    [HarmonyPatch(typeof(JetSuitLockerConfig), "CreateBuildingDef", null)]
    public static class JetSuitLockerConfigMod
    {
        public static void Postfix(BuildingDef __result)
        {
            __result.Floodable = false;
        }
    }
    [HarmonyPatch(typeof(JetSuitMarkerConfig), "CreateBuildingDef", null)]
    public static class JetSuitMarkerConfigMod
    {
        public static void Postfix(BuildingDef __result)
        {
            __result.Floodable = false;
        }
    }
    [HarmonyPatch(typeof(GasFilterConfig), "CreateBuildingDef", null)]
    public static class GasFilterMod
    {
        public static void Postfix(BuildingDef __result)
        {
            __result.EnergyConsumptionWhenActive = 10f;
        }
    }
    [HarmonyPatch(typeof(LiquidFilterConfig), "CreateBuildingDef", null)]
    public static class LiquidFilterConfigMod
    {
        public static void Postfix(BuildingDef __result)
        {
            __result.EnergyConsumptionWhenActive = 10f;
        }
    }
    [HarmonyPatch(typeof(PowerTransformerConfig), "CreateBuildingDef", null)]
    public static class PowerTransformerConfigMod
    {
        public static void Postfix(BuildingDef __result)
        {
            __result.GeneratorWattageRating = 2000f;
            __result.GeneratorBaseCapacity = 2000f;
        }
    }
    /*
    [HarmonyPatch(typeof(BatterySmartConfig), "CreateBuildingDef", null)]
    public static class BatterySmartConfigMod
    {
        public static void Postfix(BuildingDef __result)
        {
            __result.Floodable = false;
        }
    }
    [HarmonyPatch(typeof(PowerTransformerSmallConfig), "CreateBuildingDef", null)]
    public static class PowerTransformerSmallConfigMod
    {
        public static void Postfix(BuildingDef __result)
        {
            __result.Floodable = false;
        }
    }
    
        [HarmonyPatch(typeof(ElementLoader), "Load", null)]
        public static class metalspatch
        {
            public static void Postfix()
            {
                tags.add(ElementLoader.FindElementByHash(SimHashes.Copper), "Metal");
                tags.add(ElementLoader.FindElementByHash(SimHashes.Gold), "Metal");
                tags.add(ElementLoader.FindElementByHash(SimHashes.Iron), "Metal");
                tags.add(ElementLoader.FindElementByHash(SimHashes.Tungsten), "Metal");
                tags.add(ElementLoader.FindElementByHash(SimHashes.Steel), "Metal");
                tags.add(ElementLoader.FindElementByHash(SimHashes.TempConductorSolid), "Metal");
                tags.add(ElementLoader.FindElementByHash(SimHashes.TempConductorSolid), "RefinedMetal");
             }
        }
    public static class tags
    {
        public static void add(Element ele, string taglist)
        {
            if (!ele.oreTags.Contains(TagManager.Create(taglist)))
                ele.oreTags.Add(TagManager.Create(taglist));
        }
    }*/
    /*
    [HarmonyPatch(typeof(WireRefinedHighWattageConfig), "CreateBuildingDef", null)]
    public static class __WireRefinedHighWattageConfigbd
    {
        public static void Postfix(ref BuildingDef __result)
        {
            __result.BaseDecor=0;
            __result.BaseDecorRadius = 1;
        }
    }
    [HarmonyPatch(typeof(WireRefinedBridgeHighWattageConfig), "CreateBuildingDef", null)]
    public static class __WireRefinedBridgeHighWattageConfigbd
    {
        public static void Postfix(ref BuildingDef __result)
        {
            __result.BaseDecor = 0;
            __result.BaseDecorRadius = 1;
        }
    }
    */
}