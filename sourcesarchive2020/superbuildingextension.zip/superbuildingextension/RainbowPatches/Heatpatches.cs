﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Harmony;
using UnityEngine;
using STRINGS;

namespace RainbowBuildingPatches
{
    [HarmonyPatch(typeof(MainMenu), "OnSpawn", null)]
    public static class Overheatbonus
    {
        public static void Postfix()
        {
            ElementLoader.FindElementByHash(SimHashes.TempConductorSolid).attributeModifiers.Add(new Klei.AI.AttributeModifier("OverheatTemperature", 2500));
            ElementLoader.FindElementByHash(SimHashes.TempConductorSolid).highTemp = 8421.534f;
            // ElementLoader.FindElementByName("Cuprite").attributeModifiers.Add(new Klei.AI.AttributeModifier("OverheatTemperature", 50));
            // ElementLoader.FindElementByName("Cuprite").attributeModifiers.Add(new Klei.AI.AttributeModifier("OverheatTemperature", 50));
            // ElementLoader.FindElementByName("IronOre").attributeModifiers.Add(new Klei.AI.AttributeModifier("OverheatTemperature", 200));
        }
    }
    [HarmonyPatch(typeof(LiquidHeaterConfig), "ConfigureBuildingTemplate", null)]
    public static class LiquidHeaterLogicMod
    {
        public static void Postfix(LiquidHeaterConfig __instance, GameObject go)
        {
            AccessTools.Field(typeof(SpaceHeater), "targetTemperature").SetValue((object)go.AddOrGet<SpaceHeater>(), (object)10000358.15f);
        }
    }
    [HarmonyPatch(typeof(LiquidHeaterConfig), "CreateBuildingDef", null)]
    public static class LiquidHeaterMod
    {
        public static void Postfix(BuildingDef __result)
        {
            //__result.MaterialCategory = MATERIALS.ANY_BUILDABLE;
            __result.EnergyConsumptionWhenActive = 950f;
            __result.ExhaustKilowattsWhenActive = 900f;
            __result.SelfHeatKilowattsWhenActive = 16f;
        }
    }
    [HarmonyPatch(typeof(SpaceHeaterConfig), "ConfigureBuildingTemplate", null)]
    public static class SpaceHeaterLogicMod
    {
        public static void Postfix(SpaceHeaterConfig __instance, GameObject go)
        {
            AccessTools.Field(typeof(SpaceHeater), "targetTemperature").SetValue((object)go.AddOrGet<SpaceHeater>(), (object)10000358.15f);
        }
    }
    [HarmonyPatch(typeof(SpaceHeaterConfig), "CreateBuildingDef", null)]
    public static class SpaceHeaterMod
    {
        public static void Postfix(BuildingDef __result)
        {
            //__result.MaterialCategory = MATERIALS.ANY_BUILDABLE;
            __result.EnergyConsumptionWhenActive = 240f;
            __result.ExhaustKilowattsWhenActive = 200f;
            __result.SelfHeatKilowattsWhenActive = 16f;
            __result.Floodable = true;
        }
    }
}