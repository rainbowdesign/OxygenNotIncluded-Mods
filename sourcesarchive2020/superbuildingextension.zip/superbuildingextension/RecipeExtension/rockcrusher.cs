﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Harmony;
using UnityEngine;

namespace RecipeExtension
{
    public class RockCrusher
    {
        [HarmonyPatch(typeof(GeneratedBuildings), "LoadGeneratedBuildings", null)]
        public class AddRecipes
        {
            public static void Postfix()
            {
                #region basic recipes


                float num1 = 0.01f;
                float num2 = (float)((1.0 - (double)num1) * 0.5);
                float num3 = 0.15f;
                float num4 = 0.05f;
                float num5 = 1f - num4 - num3;
                float num6 = 0.05f;
                float num7 = 0.35f;



                /*
			ComplexRecipe.RecipeElement[] ingredientsb2 = new ComplexRecipe.RecipeElement[2]
			{
	  new ComplexRecipe.RecipeElement(SimHashes.SolidMercury.CreateTag(), 50f),
	  new ComplexRecipe.RecipeElement(SimHashes.TempConductorSolid.CreateTag(), 50f )
			};
			ComplexRecipe.RecipeElement[] resultsb2 = new ComplexRecipe.RecipeElement[1]
			{
	  new ComplexRecipe.RecipeElement(SimHashes.Radium.CreateTag(), 100f)
			};
			ComplexRecipe complexRecipeb3 = new ComplexRecipe(ComplexRecipeManager.MakeRecipeID(IDS.ID, (IList<ComplexRecipe.RecipeElement>)ingredientsb2, (IList<ComplexRecipe.RecipeElement>)resultsb2), ingredientsb2, resultsb2);
			complexRecipeb3.time = 80f;
			complexRecipeb3.description = (string)STRINGS.BUILDINGS.PREFABS.SUPERMATERIALREFINERY.SUPERCOOLANT_RECIPE_DESCRIPTION;
			//complexRecipeb3.useResultAsDescription = true;
			complexRecipeb3.fabricators = new List<Tag>() { TagManager.Create(IDS.ID) };
            */
                Tag tag = SimHashes.Sand.CreateTag();
                foreach (Element element in ElementLoader.elements.FindAll((Predicate<Element>)(e => e.HasTag(GameTags.Crushable))))
                {
                    Co.Add.Recipe("AutoRockCrusher", 80,
                   new ComplexRecipe.RecipeElement[1]                {
        new ComplexRecipe.RecipeElement(element.tag, 100f)
                    },
                     new ComplexRecipe.RecipeElement[1]
                    {
        new ComplexRecipe.RecipeElement(tag, 100f)
                    });
                }

                foreach (Element element in ElementLoader.elements.FindAll((Predicate<Element>)(e =>
               {
                   if (e.IsSolid)
                       return e.HasTag(GameTags.Metal);
                   return false;
               })))
                {
                    Element lowTempTransition = element.highTempTransition.lowTempTransition;
                    if (lowTempTransition != element)
                    {

                        Co.Add.Recipe("AutoRockCrusher", 80, new ComplexRecipe.RecipeElement[1]
                            {
          new ComplexRecipe.RecipeElement(element.tag, 100f)
                            },
                            new ComplexRecipe.RecipeElement[2]
                            {
          new ComplexRecipe.RecipeElement(lowTempTransition.tag, 50f),
          new ComplexRecipe.RecipeElement(tag, 50f)
                            });
                    }
                }
            Tag elementlime = ElementLoader.FindElementByHash(SimHashes.Lime).tag;
                Co.Add.Recipe("AutoRockCrusher", 80,
            new ComplexRecipe.RecipeElement[1]
            {
      new ComplexRecipe.RecipeElement((Tag) "EggShell", 5f)
            },
             new ComplexRecipe.RecipeElement[1]
            {
      new ComplexRecipe.RecipeElement(elementlime, 5f)
            });
                Co.Add.Recipe("AutoRockCrusher", 80,
            new ComplexRecipe.RecipeElement[1]
            {
      new ComplexRecipe.RecipeElement((Tag) "BabyCrabShell", 1f)
            },
             new ComplexRecipe.RecipeElement[1]
            {
      new ComplexRecipe.RecipeElement(elementlime, 5f)
            });
                Co.Add.Recipe("AutoRockCrusher", 80,
            new ComplexRecipe.RecipeElement[1]
            {
      new ComplexRecipe.RecipeElement((Tag) "CrabShell", 1f)
            },
             new ComplexRecipe.RecipeElement[1]
            {
      new ComplexRecipe.RecipeElement(elementlime, 10f)
            });
                Co.Add.Recipe("AutoRockCrusher", 80,
            new ComplexRecipe.RecipeElement[1]
            {
      new ComplexRecipe.RecipeElement((Tag) "Fossil", 100f)
            },
             new ComplexRecipe.RecipeElement[2]
            {
      new ComplexRecipe.RecipeElement(elementlime, 5f),
      new ComplexRecipe.RecipeElement(ElementLoader.FindElementByHash(SimHashes.SedimentaryRock).tag, 95f)
            });

            float num = 5E-05f;
                Co.Add.Recipe("AutoRockCrusher", 80,
            new ComplexRecipe.RecipeElement[1]
            {
      new ComplexRecipe.RecipeElement(SimHashes.Salt.CreateTag(), 100f)
            },
             new ComplexRecipe.RecipeElement[2]
            {
      new ComplexRecipe.RecipeElement(TableSaltConfig.ID.ToTag(), 100f * num),
      new ComplexRecipe.RecipeElement(SimHashes.Sand.CreateTag(), (float) (100.0 * (1.0 - (double) num)))
            });

                #endregion
                #region advanced recipes
                List<string> buildings = new List<string>() {"RockCrusher", "AutoRockCrusher" };
                Debug.Log("receipe extension");
                //carbon fiber
                Co.Add.Recipe(buildings, 40,
                        new ComplexRecipe.RecipeElement[1]      {
                new ComplexRecipe.RecipeElement((Tag)SwampLilyFlowerConfig.ID, 10f)    },
                        new ComplexRecipe.RecipeElement[2]      {
                new ComplexRecipe.RecipeElement(ElementLoader.FindElementByHash(SimHashes.BleachStone).tag, 1f),
                new ComplexRecipe.RecipeElement(ElementLoader.FindElementByHash(SimHashes.SlimeMold).tag, 9f)
                    }, "Make Bleach Stone and Slime from Swamp Lily");

                #endregion
            }
        }
    }
}
