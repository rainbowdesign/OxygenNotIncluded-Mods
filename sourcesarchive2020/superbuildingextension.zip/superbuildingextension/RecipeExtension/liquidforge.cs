﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Harmony;
using UnityEngine;

namespace RecipeExtension
{
    public class LiquidForge
    {
        [HarmonyPatch(typeof(GeneratedBuildings), "LoadGeneratedBuildings", null)]
        public class AddRecipes
        {
            public static void Postfix()
            {
                #region basic recipes


                Co.Add.Recipe("LiquidForge", 40, new ComplexRecipe.RecipeElement[1]            {
                 new ComplexRecipe.RecipeElement(ElementLoader.FindElementByHash(SimHashes.Sand).tag, 100f)            },
                    new ComplexRecipe.RecipeElement[1]         {
                 new ComplexRecipe.RecipeElement(ElementLoader.FindElementByHash(SimHashes.MoltenGlass).tag, 25f)      });
                List<string> buildings = new List<string>() { "LiquidForge", "GlassForge" };


                Co.Add.Recipe(buildings, 40,
                    new ComplexRecipe.RecipeElement[1]      {
                new ComplexRecipe.RecipeElement(ElementLoader.FindElementByHash(SimHashes.RefinedCarbon).tag, 100f)     },
                    new ComplexRecipe.RecipeElement[1]      {
                new ComplexRecipe.RecipeElement(ElementLoader.FindElementByHash(SimHashes.CrudeOil).tag, 100f)            });
                Co.Add.Recipe(buildings, 40,
                    new ComplexRecipe.RecipeElement[1]      {
                new ComplexRecipe.RecipeElement(ElementLoader.FindElementByHash(SimHashes.Algae).tag, 100f)     },
                    new ComplexRecipe.RecipeElement[1]      {
                new ComplexRecipe.RecipeElement(ElementLoader.FindElementByHash(SimHashes.CrudeOil).tag, 100f)            });


                #endregion
            }
        }
    }
}