﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Harmony;
using UnityEngine;

namespace RecipeExtension
{
    public class superrefinery
    {
        [HarmonyPatch(typeof(GeneratedBuildings), "LoadGeneratedBuildings", null)]
        public class AddRecipes
        {
            public static void Postfix()
            {
                #region basic recipes


                float num1 = 0.01f;
                float num2 = (float)((1.0 - (double)num1) * 0.5);
                float num3 = 0.15f;
                float num4 = 0.05f;
                float num5 = 1f - num4 - num3;
                float num6 = 0.05f;
                float num7 = 0.35f;



                /*
			ComplexRecipe.RecipeElement[] ingredientsb2 = new ComplexRecipe.RecipeElement[2]
			{
	  new ComplexRecipe.RecipeElement(SimHashes.SolidMercury.CreateTag(), 50f),
	  new ComplexRecipe.RecipeElement(SimHashes.TempConductorSolid.CreateTag(), 50f )
			};
			ComplexRecipe.RecipeElement[] resultsb2 = new ComplexRecipe.RecipeElement[1]
			{
	  new ComplexRecipe.RecipeElement(SimHashes.Radium.CreateTag(), 100f)
			};
			ComplexRecipe complexRecipeb3 = new ComplexRecipe(ComplexRecipeManager.MakeRecipeID(IDS.ID, (IList<ComplexRecipe.RecipeElement>)ingredientsb2, (IList<ComplexRecipe.RecipeElement>)resultsb2), ingredientsb2, resultsb2);
			complexRecipeb3.time = 80f;
			complexRecipeb3.description = (string)STRINGS.BUILDINGS.PREFABS.SUPERMATERIALREFINERY.SUPERCOOLANT_RECIPE_DESCRIPTION;
			//complexRecipeb3.useResultAsDescription = true;
			complexRecipeb3.fabricators = new List<Tag>() { TagManager.Create(IDS.ID) };
            */
                Co.Add.Recipe("AutoSupermaterialRefinery", 80,
             new ComplexRecipe.RecipeElement[3]
                {
      new ComplexRecipe.RecipeElement(SimHashes.Fullerene.CreateTag(), 100f * num1),
      new ComplexRecipe.RecipeElement(SimHashes.Gold.CreateTag(), 100f * num2),
      new ComplexRecipe.RecipeElement(SimHashes.Petroleum.CreateTag(), 100f * num2)
                },
                new ComplexRecipe.RecipeElement[1]
                {
      new ComplexRecipe.RecipeElement(SimHashes.SuperCoolant.CreateTag(), 100f)
                });
                Co.Add.Recipe("AutoSupermaterialRefinery", 80,
               new ComplexRecipe.RecipeElement[3]
                {
      new ComplexRecipe.RecipeElement(SimHashes.Isoresin.CreateTag(), 100f * num3),
      new ComplexRecipe.RecipeElement(SimHashes.Katairite.CreateTag(), 100f * num5),
      new ComplexRecipe.RecipeElement(BasicFabricConfig.ID.ToTag(), 100f * num4)
                },
                new ComplexRecipe.RecipeElement[1]
                {
      new ComplexRecipe.RecipeElement(SimHashes.SuperInsulator.CreateTag(), 100f)
                });
                Co.Add.Recipe("AutoSupermaterialRefinery", 80,
                new ComplexRecipe.RecipeElement[2]
                {
      new ComplexRecipe.RecipeElement(SimHashes.Niobium.CreateTag(), 100f * num6),
      new ComplexRecipe.RecipeElement(SimHashes.Tungsten.CreateTag(), (float) (100.0 * (1.0 - (double) num6)))
                },
                 new ComplexRecipe.RecipeElement[1]
                {
      new ComplexRecipe.RecipeElement(SimHashes.TempConductorSolid.CreateTag(), 100f)
                });
                Co.Add.Recipe("AutoSupermaterialRefinery", 80,
             new ComplexRecipe.RecipeElement[2]
            {
      new ComplexRecipe.RecipeElement(SimHashes.Isoresin.CreateTag(), 100f * num7),
      new ComplexRecipe.RecipeElement(SimHashes.Petroleum.CreateTag(), (float) (100.0 * (1.0 - (double) num7)))
            },
            new ComplexRecipe.RecipeElement[1]
            {
      new ComplexRecipe.RecipeElement(SimHashes.ViscoGel.CreateTag(), 100f)
            });

                #endregion
                #region advanced recipes
                List<string> buildings = new List<string>() {"SupermaterialRefinery", "AutoSupermaterialRefinery" };
                Debug.Log("receipe extension");
                //carbon fiber
                Co.Add.Recipe(buildings, 120,
			 new ComplexRecipe.RecipeElement[4]			{
				new ComplexRecipe.RecipeElement(ElementLoader.FindElementByHash(SimHashes.Tungsten).tag, 50f),
		new ComplexRecipe.RecipeElement(ElementLoader.FindElementByHash(SimHashes.MaficRock).tag, 50f),
		new ComplexRecipe.RecipeElement(ElementLoader.FindElementByHash(SimHashes.Obsidian).tag, 100f),
		new ComplexRecipe.RecipeElement(ElementLoader.FindElementByHash(SimHashes.SuperCoolant).tag, 50f),	},
			 new ComplexRecipe.RecipeElement[1]			{
	  new ComplexRecipe.RecipeElement(SimHashes.SolidMercury.CreateTag(), 100f)
			});

                Co.Add.Recipe(buildings, 120,
                        new ComplexRecipe.RecipeElement[1]      {
                new ComplexRecipe.RecipeElement(ElementLoader.FindElementByHash(SimHashes.RefinedCarbon).tag, 200f)    },
                        new ComplexRecipe.RecipeElement[1]      {
                new ComplexRecipe.RecipeElement(BasicFabricConfig.ID, 1f)
                    }, "Make Carbon fibre Fabric from Carbon");

                //Fertilizer
                Co.Add.Recipe(buildings, 40,
                        new ComplexRecipe.RecipeElement[2]      {
                new ComplexRecipe.RecipeElement(ElementLoader.FindElementByHash(SimHashes.Sulfur).tag, 30f),
                new ComplexRecipe.RecipeElement(ElementLoader.FindElementByHash(SimHashes.Dirt).tag, 100f)     },
                        new ComplexRecipe.RecipeElement[1]      {
                new ComplexRecipe.RecipeElement(ElementLoader.FindElementByHash(SimHashes.Fertilizer).tag, 130f)
                    });

                // slime purifyer
                Co.Add.Recipe(buildings, 40,
                        new ComplexRecipe.RecipeElement[2]      {
                new ComplexRecipe.RecipeElement(ElementLoader.FindElementByHash(SimHashes.SlimeMold).tag, 200f)    ,
                new ComplexRecipe.RecipeElement(ElementLoader.FindElementByHash(SimHashes.BleachStone).tag, 1f)    },
                        new ComplexRecipe.RecipeElement[1]      {
                new ComplexRecipe.RecipeElement(ElementLoader.FindElementByHash(SimHashes.Dirt).tag, 200f)
                    });
                // dirt dirtier purifyer
                Co.Add.Recipe(buildings, 40,
                        new ComplexRecipe.RecipeElement[2]      {
                new ComplexRecipe.RecipeElement(ElementLoader.FindElementByHash(SimHashes.Dirt).tag, 200f)    ,
                new ComplexRecipe.RecipeElement(ElementLoader.FindElementByHash(SimHashes.SlimeMold).tag, 50f)    },
                        new ComplexRecipe.RecipeElement[1]      {
                new ComplexRecipe.RecipeElement(ElementLoader.FindElementByHash(SimHashes.ToxicSand).tag, 250f)
                    });

                //lime get
                Co.Add.Recipe(buildings, 40,
                        new ComplexRecipe.RecipeElement[1]      {
                new ComplexRecipe.RecipeElement(ElementLoader.FindElementByHash(SimHashes.Steel).tag, 100f)    },
                        new ComplexRecipe.RecipeElement[1]      {
                new ComplexRecipe.RecipeElement(ElementLoader.FindElementByHash(SimHashes.Lime).tag, 20f)       });

                Co.Add.Recipe(buildings, 40,
                        new ComplexRecipe.RecipeElement[3]      {
                new ComplexRecipe.RecipeElement(ElementLoader.FindElementByHash(SimHashes.MaficRock).tag, 100f) ,
                new ComplexRecipe.RecipeElement(ElementLoader.FindElementByHash(SimHashes.BleachStone).tag, 10f) ,
                new ComplexRecipe.RecipeElement(ElementLoader.FindElementByHash(SimHashes.RefinedCarbon).tag, 40f)    },
                        new ComplexRecipe.RecipeElement[2]      {
                new ComplexRecipe.RecipeElement(ElementLoader.FindElementByHash(SimHashes.IronOre).tag, 50f)  ,
                new ComplexRecipe.RecipeElement(ElementLoader.FindElementByHash(SimHashes.Sand).tag, 100f)         });


                // slime purifyer
                Co.Add.Recipe(buildings, 40,
                        new ComplexRecipe.RecipeElement[3]      {
                new ComplexRecipe.RecipeElement(ElementLoader.FindElementByHash(SimHashes.MaficRock).tag, 70f)    ,
                new ComplexRecipe.RecipeElement(ElementLoader.FindElementByHash(SimHashes.IgneousRock).tag, 20f)    ,
                new ComplexRecipe.RecipeElement(ElementLoader.FindElementByHash(SimHashes.Sulfur).tag, 10f)    },
                        new ComplexRecipe.RecipeElement[2]      {
                new ComplexRecipe.RecipeElement(ElementLoader.FindElementByHash(SimHashes.Wolframite).tag, 50f)    ,
                new ComplexRecipe.RecipeElement(ElementLoader.FindElementByHash(SimHashes.Sand).tag, 50f)
                    });
                #endregion
            }
        }
    }
}
