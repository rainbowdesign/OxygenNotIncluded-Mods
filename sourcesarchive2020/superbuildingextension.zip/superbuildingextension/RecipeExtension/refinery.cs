﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Harmony;
using UnityEngine;

namespace RecipeExtension
{
    public class AutoRefinery
    {
        
        [HarmonyPatch(typeof(GeneratedBuildings), "LoadGeneratedBuildings", null)]
        public class AddRecipes
        {
            public static void Postfix()
            {
                #region basic recipes
                
			List<Element> targetelements = new List<Element>();
			targetelements.Add(ElementLoader.FindElementByHash(SimHashes.Wolframite));
			targetelements.Add(ElementLoader.FindElementByHash(SimHashes.GoldAmalgam));
			targetelements.Add(ElementLoader.FindElementByHash(SimHashes.IronOre));
			targetelements.Add(ElementLoader.FindElementByHash(SimHashes.Cuprite));
			targetelements.Add(ElementLoader.FindElementByHash(SimHashes.Aluminum));

			foreach (Element element in targetelements) {
				Element lowTempTransition = element.highTempTransition.lowTempTransition;
				if (lowTempTransition != element) {
					ComplexRecipe.RecipeElement[] ingredients = new ComplexRecipe.RecipeElement[1]
					{
		  new ComplexRecipe.RecipeElement(element.tag, 100f)
					};
					ComplexRecipe.RecipeElement[] results = new ComplexRecipe.RecipeElement[1]
					{
		  new ComplexRecipe.RecipeElement(lowTempTransition.tag, 100f)
					};

					
                Co.Add.Recipe("AutoRefinery",  40, ingredients, results);
				}
			}
            /*
            Co.Add.Recipe("MetalRefinery", 200,
				new ComplexRecipe.RecipeElement[2]      {
				new ComplexRecipe.RecipeElement(ElementLoader.FindElementByHash(SimHashes.MaficRock).tag, 300f),
				new ComplexRecipe.RecipeElement(ElementLoader.FindElementByHash(SimHashes.Water).tag, 50f) },
				new ComplexRecipe.RecipeElement[2]      {
				new ComplexRecipe.RecipeElement(ElementLoader.FindElementByHash(SimHashes.IronOre).tag, 100f),
				new ComplexRecipe.RecipeElement(ElementLoader.FindElementByHash(SimHashes.Sand).tag,200) },"Extract Ironore from Mafic Rock");
		*/
                Co.Add.Recipe("AutoRefinery", 40,
			 new ComplexRecipe.RecipeElement[3]
			{
	  new ComplexRecipe.RecipeElement(ElementLoader.FindElementByHash(SimHashes.Iron).tag, 70f),
	  new ComplexRecipe.RecipeElement(ElementLoader.FindElementByHash(SimHashes.RefinedCarbon).tag, 20f),
	  new ComplexRecipe.RecipeElement(ElementLoader.FindElementByHash(SimHashes.Lime).tag, 10f)
			},
			 new ComplexRecipe.RecipeElement[1]
			{
	  new ComplexRecipe.RecipeElement(ElementLoader.FindElementByHash(SimHashes.Steel).tag, 100f)
			});

                #endregion
            }
        }
    }
}
