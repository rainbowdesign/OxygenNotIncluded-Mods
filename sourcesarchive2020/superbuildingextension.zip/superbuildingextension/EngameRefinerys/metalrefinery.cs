﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using Harmony;
using TUNING;
using UnityEngine;

namespace AutoRefinery
{

	internal class IDS
	{
		public const string ID = "AutoRefinery";
		public const string NAME = "Automatic Refinery";
		public const string DESCRIPTION = "The Automatic Refinery does not need a duplicant to work and has extra recipes.";
		public const string EFFECT = "Metal Refinery that does not need a Duplicant to operate.";
		public const string TECH = "DupeTrafficControl";
		public const string PLANCATEGORY = "Refining";
	}
	[HarmonyPatch(typeof(GeneratedBuildings), "LoadGeneratedBuildings")]
	internal class __LoadGeneratedBuildings
	{
		private static void Prefix()
		{
            Co.Add.BuildingPlan(IDS.ID, IDS.NAME, IDS.DESCRIPTION, IDS.EFFECT, IDS.PLANCATEGORY);
		}
	}
	[HarmonyPatch(typeof(Db), "Initialize")]
	internal class __Db_Initialize
	{
		private static void Prefix(Db __instance)
		{
            Co.Add.BuildingTech(IDS.ID, IDS.TECH);
        }
	}


	public class AutoRefineryConfig : IBuildingConfig
	{
		public const string ID = IDS.ID;
        private static readonly Tag COOLANT_TAG = GameTags.Liquid;
        private static readonly List<Storage.StoredItemModifier> RefineryStoredItemModifiers = new List<Storage.StoredItemModifier>()
  {
    Storage.StoredItemModifier.Hide,
    Storage.StoredItemModifier.Preserve,
    Storage.StoredItemModifier.Insulate,
    Storage.StoredItemModifier.Seal
  };
        private const float INPUT_KG = 100f;
        private const float LIQUID_COOLED_HEAT_PORTION = 0.8f;
        private const float COOLANT_MASS = 400f;

        public override BuildingDef CreateBuildingDef()
		{
			string id = IDS.ID;
			int width = 3;
			int height = 4;
			string anim = "metalrefinery_kanim";
			int hitpoints = 30;
			float construction_time = 60f;
			string[] allMinerals = new string[3] {
	  "Steel",
	  "Plastic",
	   SimHashes.TempConductorSolid.CreateTag().Name };
			float[] tieR5 = new float[3]            {
	  TUNING.BUILDINGS.CONSTRUCTION_MASS_KG.TIER6[0],
	  TUNING.BUILDINGS.CONSTRUCTION_MASS_KG.TIER5[0],
	  TUNING.BUILDINGS.CONSTRUCTION_MASS_KG.TIER4[0]};
			float melting_point = 2400f;
			BuildLocationRule build_location_rule = BuildLocationRule.OnFloor;
			EffectorValues tieR6 = TUNING.NOISE_POLLUTION.NOISY.TIER6;
			BuildingDef buildingDef = BuildingTemplates.CreateBuildingDef(id, width, height, anim, hitpoints, construction_time, tieR5, allMinerals, melting_point, build_location_rule, TUNING.BUILDINGS.DECOR.PENALTY.TIER2, tieR6, 0.2f);
			buildingDef.RequiresPowerInput = true;
			buildingDef.EnergyConsumptionWhenActive = 3200f;
			buildingDef.SelfHeatKilowattsWhenActive = 16f;
			buildingDef.InputConduitType = ConduitType.Liquid;
			buildingDef.UtilityInputOffset = new CellOffset(-1, 1);
			buildingDef.OutputConduitType = ConduitType.Liquid;
			buildingDef.UtilityOutputOffset = new CellOffset(1, 0);
			buildingDef.ViewMode = OverlayModes.Power.ID;
			buildingDef.AudioCategory = "HollowMetal";
			buildingDef.AudioSize = "large";
			return buildingDef;
		}

		public override void ConfigureBuildingTemplate(GameObject go, Tag prefab_tag)
		{
			go.AddOrGet<DropAllWorkable>();
			go.AddOrGet<BuildingComplete>().isManuallyOperated = false;
			LiquidCooledRefinery liquidCooledRefinery = go.AddOrGet<LiquidCooledRefinery>();
			liquidCooledRefinery.duplicantOperated = false;
			liquidCooledRefinery.sideScreenStyle = ComplexFabricatorSideScreen.StyleSetting.ListQueueHybrid;
			liquidCooledRefinery.keepExcessLiquids = true;
            go.AddOrGet<FabricatorIngredientStatusManager>();
			go.AddOrGet<CopyBuildingSettings>();
			ComplexFabricatorWorkable fabricatorWorkable = go.AddOrGet<ComplexFabricatorWorkable>();
            BuildingTemplates.CreateComplexFabricatorStorage(go, (ComplexFabricator)liquidCooledRefinery);
			liquidCooledRefinery.coolantTag = AutoRefineryConfig.COOLANT_TAG;
			liquidCooledRefinery.minCoolantMass = 400f;
			liquidCooledRefinery.outStorage.capacityKg = 2000f;
			liquidCooledRefinery.thermalFudge = 0.8f;
			liquidCooledRefinery.inStorage.SetDefaultStoredItemModifiers(AutoRefineryConfig.RefineryStoredItemModifiers);
			liquidCooledRefinery.buildStorage.SetDefaultStoredItemModifiers(AutoRefineryConfig.RefineryStoredItemModifiers);
			liquidCooledRefinery.outStorage.SetDefaultStoredItemModifiers(AutoRefineryConfig.RefineryStoredItemModifiers);
			liquidCooledRefinery.outputOffset = new Vector3(1f, 0.5f);
			go.AddOrGet<KAnimControllerBase>();
			fabricatorWorkable.overrideAnims = new KAnimFile[1]			{
	  Assets.GetAnim((HashedString) "anim_interacts_autorefinery_kanim")			};
			go.AddOrGet<RequireOutputs>().ignoreFullPipe = true;
			ConduitConsumer conduitConsumer = go.AddOrGet<ConduitConsumer>();
			conduitConsumer.capacityTag = GameTags.Liquid;
			conduitConsumer.capacityKG = 800f;
			conduitConsumer.storage = liquidCooledRefinery.inStorage;
			conduitConsumer.alwaysConsume = true;
			conduitConsumer.forceAlwaysSatisfied = true;
			ConduitDispenser conduitDispenser = go.AddOrGet<ConduitDispenser>();
			conduitDispenser.storage = liquidCooledRefinery.outStorage;
			conduitDispenser.conduitType = ConduitType.Liquid;
			conduitDispenser.elementFilter = (SimHashes[])null;
			conduitDispenser.alwaysDispense = true;

			//recipes

		}

		public override void DoPostConfigureComplete(GameObject go)
		{
			SymbolOverrideControllerUtil.AddToPrefab(go);
			go.AddOrGetDef<PoweredActiveStoppableController.Def>();
		}

	}
}
