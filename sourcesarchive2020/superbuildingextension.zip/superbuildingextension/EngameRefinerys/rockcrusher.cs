﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using Harmony;
using TUNING;
using UnityEngine;

namespace AutoRockCrusher
{

    internal class IDS
    {
        public const string ID = "AutoRockCrusher";
        public const string NAME = "Automatic Rock Crusher";
        public const string DESCRIPTION = "The Automatic Rock Crusher does not need a duplicant to work and has extra recipes.";
        public const string EFFECT = "Rock Crusher Refinery that does not need a Duplicant to operate.";
        public const string TECH = "DupeTrafficControl";
        public const string PLANCATEGORY = "Refining";
    }
    [HarmonyPatch(typeof(GeneratedBuildings), "LoadGeneratedBuildings")]
    internal class __LoadGeneratedBuildings
    {
        private static void Prefix()
        {
            Co.Add.BuildingPlan(IDS.ID, IDS.NAME, IDS.DESCRIPTION, IDS.EFFECT, IDS.PLANCATEGORY);
        }
    }
    [HarmonyPatch(typeof(Db), "Initialize")]
    internal class __Db_Initialize
    {
        private static void Prefix(Db __instance)
        {
            Co.Add.BuildingTech(IDS.ID, IDS.TECH);
        }
    }


    public class AutoRockCrusherConfig : IBuildingConfig
    {
        public const string ID = IDS.ID;
        private const float INPUT_KG = 100f;
        private const float METAL_ORE_EFFICIENCY = 0.5f;

        public override BuildingDef CreateBuildingDef()
        {
            string id = IDS.ID;
            int width = 4;
            int height = 4;
            string anim = "rockrefinery_kanim";
            int hitpoints = 30;
            float construction_time = 60f;
			string[] allMetals = new string[3] {
	  "Steel",
	  "Plastic",
	   SimHashes.TempConductorSolid.CreateTag().Name };
			float[] tieR5 = new float[3]            {
	  TUNING.BUILDINGS.CONSTRUCTION_MASS_KG.TIER6[0],
	  TUNING.BUILDINGS.CONSTRUCTION_MASS_KG.TIER5[0],
	  TUNING.BUILDINGS.CONSTRUCTION_MASS_KG.TIER4[0]};
            float melting_point = 2400f;
            BuildLocationRule build_location_rule = BuildLocationRule.OnFloor;
            EffectorValues tieR6 = TUNING.NOISE_POLLUTION.NOISY.TIER6;
            BuildingDef buildingDef = BuildingTemplates.CreateBuildingDef(id, width, height, anim, hitpoints, construction_time, tieR5, allMetals, melting_point, build_location_rule, TUNING.BUILDINGS.DECOR.PENALTY.TIER2, tieR6, 0.2f);
            buildingDef.RequiresPowerInput = true;
            buildingDef.EnergyConsumptionWhenActive = 2500f;
            buildingDef.SelfHeatKilowattsWhenActive = 16f;
            buildingDef.ViewMode = OverlayModes.Power.ID;
            buildingDef.AudioCategory = "HollowMetal";
            buildingDef.AudioSize = "large";
            return buildingDef;
        }

        public override void ConfigureBuildingTemplate(GameObject go, Tag prefab_tag)
        {
            go.AddOrGet<DropAllWorkable>();
            go.AddOrGet<BuildingComplete>().isManuallyOperated = false;
            ComplexFabricator fabricator = go.AddOrGet<ComplexFabricator>();
            fabricator.sideScreenStyle = ComplexFabricatorSideScreen.StyleSetting.ListQueueHybrid;
            fabricator.duplicantOperated = false;
            go.AddOrGet<FabricatorIngredientStatusManager>();
            go.AddOrGet<CopyBuildingSettings>();
            BuildingTemplates.CreateComplexFabricatorStorage(go, fabricator);
            Prioritizable.AddRef(go);
        }

        public override void DoPostConfigureComplete(GameObject go)
        {
            SymbolOverrideControllerUtil.AddToPrefab(go);
        }
    }
}
