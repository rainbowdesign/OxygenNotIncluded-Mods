﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using Harmony;
using TUNING;
using UnityEngine;

using KSerialization;
using System.Collections.Generic;

namespace LiquidForge
{

	internal class IDS
	{
		public const string ID = "LiquidForge";
		public const string NAME = "Automatic Liquidforge";
		public const string DESCRIPTION = "The Automatic Liquidforge does not need a duplicant to work and has extra recipes.";
		public const string EFFECT = "Expensive Forge that makes liquids from Solids and does not need a duplicant to operate.";
		public const string TECH = "DupeTrafficControl";
		public const string PLANCATEGORY = "Refining";
	}
	[HarmonyPatch(typeof(GeneratedBuildings), "LoadGeneratedBuildings")]
	internal class __LoadGeneratedBuildings
	{
		private static void Prefix()
		{
            Co.Add.BuildingPlan(IDS.ID, IDS.NAME, IDS.DESCRIPTION, IDS.EFFECT, IDS.PLANCATEGORY);
		}
	}
	[HarmonyPatch(typeof(Db), "Initialize")]
	internal class __Db_Initialize
	{
		private static void Prefix(Db __instance)
		{
            Co.Add.BuildingTech(IDS.ID, IDS.TECH);
        }
	}


	public class AutoLiquidForgeConfig : IBuildingConfig
	{
		public const string ID = IDS.ID;
		private const float INPUT_KG = 100f;
        public static readonly CellOffset outPipeOffset = new CellOffset(1, 3);
        private static readonly List<Storage.StoredItemModifier> RefineryStoredItemModifiers = new List<Storage.StoredItemModifier>()
  {
    Storage.StoredItemModifier.Hide,
    Storage.StoredItemModifier.Preserve
  };
        public override BuildingDef CreateBuildingDef()
		{
			string id = IDS.ID;
			int width = 5;
			int height = 4;
			string anim = "glassrefinery_kanim";
			int hitpoints = 30;
			float construction_time = 60f;
			string[] allMinerals = new string[3] {
	  "Steel",
	  "Plastic",
		SimHashes.TempConductorSolid.CreateTag().Name};
			float[] tieR5 = new float[3]            {
	  TUNING.BUILDINGS.CONSTRUCTION_MASS_KG.TIER6[0],
	  TUNING.BUILDINGS.CONSTRUCTION_MASS_KG.TIER5[0],
	  TUNING.BUILDINGS.CONSTRUCTION_MASS_KG.TIER4[0]};
			float melting_point = 2400f;
			BuildLocationRule build_location_rule = BuildLocationRule.OnFloor;
			EffectorValues tieR6 = TUNING.NOISE_POLLUTION.NOISY.TIER6;
			BuildingDef buildingDef = BuildingTemplates.CreateBuildingDef(id, width, height, anim, hitpoints, construction_time, tieR5, allMinerals, melting_point, build_location_rule, TUNING.BUILDINGS.DECOR.PENALTY.TIER2, tieR6, 0.2f);
			buildingDef.RequiresPowerInput = true;
			buildingDef.EnergyConsumptionWhenActive = 3200f;
			buildingDef.SelfHeatKilowattsWhenActive = 16f;
			buildingDef.OutputConduitType = ConduitType.Liquid;
			buildingDef.UtilityOutputOffset = AutoLiquidForgeConfig.outPipeOffset;
			buildingDef.ViewMode = OverlayModes.Power.ID;
			buildingDef.AudioCategory = "HollowMetal";
			buildingDef.AudioSize = "large";
			return buildingDef;
		}

		public override void ConfigureBuildingTemplate(GameObject go, Tag prefab_tag)
		{
			go.AddOrGet<DropAllWorkable>();
			go.AddOrGet<BuildingComplete>().isManuallyOperated = false;
            GlassForge LiquidForge = go.AddOrGet<GlassForge>();
			LiquidForge.sideScreenStyle = ComplexFabricatorSideScreen.StyleSetting.ListQueueHybrid;
			go.AddOrGet<FabricatorIngredientStatusManager>();
			go.AddOrGet<CopyBuildingSettings>();
			ComplexFabricatorWorkable fabricatorWorkable = go.AddOrGet<ComplexFabricatorWorkable>();
			LiquidForge.duplicantOperated = false;
			BuildingTemplates.CreateComplexFabricatorStorage(go, (ComplexFabricator)LiquidForge);
			LiquidForge.outStorage.capacityKg = 2000f;
			LiquidForge.storeProduced = true;
			LiquidForge.inStorage.SetDefaultStoredItemModifiers(AutoLiquidForgeConfig.RefineryStoredItemModifiers);
			LiquidForge.buildStorage.SetDefaultStoredItemModifiers(AutoLiquidForgeConfig.RefineryStoredItemModifiers);
			LiquidForge.outStorage.SetDefaultStoredItemModifiers(AutoLiquidForgeConfig.RefineryStoredItemModifiers);
			LiquidForge.outputOffset = new Vector3(1f, 0.5f);
			fabricatorWorkable.overrideAnims = new KAnimFile[1]
			{
	  Assets.GetAnim((HashedString) "anim_interacts_metalrefinery_kanim")
			};
			LiquidForge.resultState = ComplexFabricator.ResultState.Melted;
			ConduitDispenser conduitDispenser = go.AddOrGet<ConduitDispenser>();
			conduitDispenser.storage = LiquidForge.outStorage;
			conduitDispenser.conduitType = ConduitType.Liquid;
			conduitDispenser.elementFilter = (SimHashes[])null;
			conduitDispenser.alwaysDispense = true;
			Prioritizable.AddRef(go);


		}

		public override void DoPostConfigureComplete(GameObject go)
		{
			SymbolOverrideControllerUtil.AddToPrefab(go);
			go.AddOrGetDef<PoweredActiveStoppableController.Def>();
		}

		static AutoLiquidForgeConfig()
		{
			AutoLiquidForgeConfig.outPipeOffset = new CellOffset(1, 3);
			List<Storage.StoredItemModifier> storedItemModifierList = new List<Storage.StoredItemModifier>();
			storedItemModifierList.Add(Storage.StoredItemModifier.Hide);
			storedItemModifierList.Add(Storage.StoredItemModifier.Preserve);
			AutoLiquidForgeConfig.RefineryStoredItemModifiers = storedItemModifierList;
		}
	}
    /*
    public class AutomatedLiquidForge : ComplexFabricator
    {
        private static readonly EventSystem.IntraObjectHandler<AutomatedLiquidForge> CheckPipesDelegate = new EventSystem.IntraObjectHandler<AutomatedLiquidForge>((System.Action<AutomatedLiquidForge, object>)((component, data) => component.CheckPipes(data)));
        private Guid statusHandle;

        protected override void OnPrefabInit()
        {
            base.OnPrefabInit(); 
            this.Subscribe<AutomatedLiquidForge>(-2094018600, AutomatedLiquidForge.CheckPipesDelegate);
        }

        private void CheckPipes(object data)
        {
            KSelectable component = this.GetComponent<KSelectable>();
            int index = Grid.OffsetCell(Grid.PosToCell((KMonoBehaviour)this), GlassForgeConfig.outPipeOffset);
            GameObject gameObject = Grid.Objects[index, 16];
            if ((UnityEngine.Object)gameObject != (UnityEngine.Object)null)
            {
                if ((double)gameObject.GetComponent<PrimaryElement>().Element.highTemp > (double)ElementLoader.FindElementByHash(SimHashes.MoltenGlass).lowTemp)
                    component.RemoveStatusItem(this.statusHandle, false);
                else
                    this.statusHandle = component.AddStatusItem(Db.Get().BuildingStatusItems.PipeMayMelt, (object)null);
            }
            else
                component.RemoveStatusItem(this.statusHandle, false);
        }
    }*/

}
