﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using Harmony;
using TUNING;
using UnityEngine;

namespace oilrefinery
{

	internal class IDS
	{
		public const string ID = "autooilrefinery";
		public const string NAME = "Automatic Oil Refinery";
		public const string DESCRIPTION = "The Oil Refinery does not need a duplicant to work.";
		public const string EFFECT = "Useful if you can afford it and want to save duplicant time.";
		public const string TECH = "DupeTrafficControl";
		public const string PLANCATEGORY = "Refining";
	}
	[HarmonyPatch(typeof(GeneratedBuildings), "LoadGeneratedBuildings")]
	internal class __LoadGeneratedBuildings
	{
		private static void Prefix()
		{
			Strings.Add("STRINGS.BUILDINGS.PREFABS." + IDS.ID.ToUpper() + ".NAME", IDS.NAME);
			Strings.Add("STRINGS.BUILDINGS.PREFABS." + IDS.ID.ToUpper() + ".DESC", IDS.DESCRIPTION);
			Strings.Add("STRINGS.BUILDINGS.PREFABS." + IDS.ID.ToUpper() + ".EFFECT", IDS.EFFECT);

			List<string> category = (List<string>)TUNING.BUILDINGS.PLANORDER.First(po => ((HashedString)IDS.PLANCATEGORY).Equals(po.category)).data;
			category.Add(IDS.ID);

			//TUNING.BUILDINGS.COMPONENT_DESCRIPTION_ORDER.Add(typeof(PressureLiquidReservoirConfig));
		}
	}
	[HarmonyPatch(typeof(Db), "Initialize")]
	internal class __Db_Initialize
	{
		private static void Prefix(Db __instance)
		{
			List<string> ls = new List<string>((string[])Database.Techs.TECH_GROUPING[IDS.TECH]);
			ls.Add(IDS.ID);
			Database.Techs.TECH_GROUPING[IDS.TECH] = (string[])ls.ToArray();
		}
	}

	public class AutoOilRefineryConfig : IBuildingConfig
	{
		public const string ID = IDS.ID;
		public const SimHashes INPUT_ELEMENT = SimHashes.CrudeOil;
		private const SimHashes OUTPUT_LIQUID_ELEMENT = SimHashes.Petroleum;
		private const SimHashes OUTPUT_GAS_ELEMENT = SimHashes.Methane;
		public const float CONSUMPTION_RATE = 10f;
		public const float OUTPUT_LIQUID_RATE = 5f;
		public const float OUTPUT_GAS_RATE = 0.09f;


		public override BuildingDef CreateBuildingDef()
		{
			string id = IDS.ID;
			int width = 4;
			int height = 4;
			string anim = "oilrefinery_kanim";
			int hitpoints = 30;
			float construction_time = 30f;
			string[] allMetals = new string[3] {
	  "Steel",
	  "Plastic",
	   SimHashes.TempConductorSolid.CreateTag().Name };
			float[] tieR3_1 = new float[3]            {
	  TUNING.BUILDINGS.CONSTRUCTION_MASS_KG.TIER6[0],
	  TUNING.BUILDINGS.CONSTRUCTION_MASS_KG.TIER5[0],
	  TUNING.BUILDINGS.CONSTRUCTION_MASS_KG.TIER4[0]};
			float melting_point = 800f;
			BuildLocationRule build_location_rule = BuildLocationRule.OnFloor;
			EffectorValues tieR3_2 = NOISE_POLLUTION.NOISY.TIER3;
			BuildingDef buildingDef = BuildingTemplates.CreateBuildingDef(id, width, height, anim, hitpoints, construction_time, tieR3_1, allMetals, melting_point, build_location_rule, BUILDINGS.DECOR.PENALTY.TIER1, tieR3_2, 0.2f);
			buildingDef.RequiresPowerInput = true;
			buildingDef.PowerInputOffset = new CellOffset(1, 0);
			buildingDef.EnergyConsumptionWhenActive = 2500f;
			buildingDef.ExhaustKilowattsWhenActive = 2f;
			buildingDef.SelfHeatKilowattsWhenActive = 8f;
			buildingDef.PermittedRotations = PermittedRotations.FlipH;
			buildingDef.ViewMode = OverlayModes.LiquidConduits.ID;
			buildingDef.AudioCategory = "HollowMetal";
			buildingDef.InputConduitType = ConduitType.Liquid;
			buildingDef.UtilityInputOffset = new CellOffset(0, 0);
			buildingDef.OutputConduitType = ConduitType.Liquid;
			buildingDef.UtilityOutputOffset = new CellOffset(1, 1);
			return buildingDef;
		}

		public override void ConfigureBuildingTemplate(GameObject go, Tag prefab_tag)
		{
			go.GetComponent<KPrefabID>().AddTag(RoomConstraints.ConstraintTags.IndustrialMachinery);
			go.AddOrGet<BuildingComplete>().isManuallyOperated = false;
			OilRefinery oilref = go.AddOrGet<OilRefinery>();
			oilref.overpressureMass = 5;
			ConduitConsumer conduitConsumer = go.AddOrGet<ConduitConsumer>();
			conduitConsumer.conduitType = ConduitType.Liquid;
			conduitConsumer.consumptionRate = 10f;
			conduitConsumer.capacityTag = SimHashes.CrudeOil.CreateTag();
			conduitConsumer.wrongElementResult = ConduitConsumer.WrongElementResult.Dump;
			conduitConsumer.capacityKG = 100f;
			conduitConsumer.forceAlwaysSatisfied = true;
			ConduitDispenser conduitDispenser = go.AddOrGet<ConduitDispenser>();
			conduitDispenser.conduitType = ConduitType.Liquid;
			conduitDispenser.invertElementFilter = true;
			conduitDispenser.elementFilter = new SimHashes[1]
			{
	  SimHashes.CrudeOil
			};
			go.AddOrGet<Storage>().showInUI = true;
			ElementConverter elementConverter = go.AddOrGet<ElementConverter>();
			elementConverter.consumedElements = new ElementConverter.ConsumedElement[1]
			{
	  new ElementConverter.ConsumedElement(SimHashes.CrudeOil.CreateTag(), 10f)
			};
			elementConverter.outputElements = new ElementConverter.OutputElement[2]
			{
	  new ElementConverter.OutputElement(5f, SimHashes.Petroleum, 348.15f, true, false, 0.0f, 1f, 1f, byte.MaxValue, 0),
	  new ElementConverter.OutputElement(0.09f, SimHashes.Methane, 348.15f, false, false, 0.0f, 3f, 1f, byte.MaxValue, 0)
			};
			Prioritizable.AddRef(go);
		}

		public override void DoPostConfigureComplete(GameObject go)
		{
		}
	}

}
